#include <stdio.h>
#include <stdlib.h> /*call memory allocation library*/
#include <string.h> /*call string library*/
#include <unistd.h> /*call fork library*/
#define SIZE 256 /*define constant SIZE*/
//main function
int main() {
	int pid, wid, status, argc=0, index; /*define integer variables*/
	char input[SIZE], *argv[5], *tok, str[SIZE]; /*define input string*/
	do {
		argc=0; /*initialize argc*/
		//go the down one line
		do {
			printf("AdvShell>"); /*present "AdvShell"*/
			fgets(input,256,stdin); /*receive string from the user*/
		//check if you print ENTER
		} while (input[0]=='\n');
		//handle the last bit of the string
		if (input[strlen(input)-1]=='\n') {
			input[strlen(input)-1] = '\0';	
		}
		//use strtok method for seperate strings
		tok = strtok(input," ");
		while (tok!=NULL) {
		argv[argc]=tok;
		argc++;
		tok = strtok(NULL," ");
		}
		argv[argc] = NULL;
		//handle #c programs
		strcpy(str,"./");
		strcat(str,argv[0]);
		//use swich case
		switch (pid = fork()) {
			//check if the action succeed  
		case -1:
			perror("fork"); /*error message*/
			exit(1); /*exit from the program*/
	    //handle the son
		case 0:
			//activate the Prog(regular)
			execvp(argv[0],argv);
			//activate the Prog(restaurant)
			execvp(str,argv);
			printf("Not Supported\n"); /*error message*/
			exit(1); /*exit from the program*/
		//default option
		default:
			break;
		} /* switch */
		//wait for the son to end his process
		wid = wait(&status);
	//continue
	} while (strcmp(input,"exit"));
	return 0; /*return 0*/
}

