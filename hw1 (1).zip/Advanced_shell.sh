cc Advanced_shell.c -o Advanced_shell
cc CreateMenu.c -o CreateMenu
cc getMenu.c -o getMenu
cc MakeOrder.c -o MakeOrder
cc getPrice.c -o getPrice
cc getOrderNum.c -o getOrderNum
cc exit.c -o exit
./Advanced_shell

