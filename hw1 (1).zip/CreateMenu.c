#include <stdio.h>
#include <stdlib.h> /*call memory allocation library*/
#include <string.h> /*call string library*/
#include <unistd.h> /*call fork library*/
#include <fcntl.h> /*call files library*/
char *PresentLine(char *input1); /*define function that receive dish and present it like we need*/
//main function
int main(int argc, char *argv[]) {
	int index1, fd, index2=1, wbytes, check; /*define integer variables*/
	char input[25], *restaurant_menu, temp[5], temp1[] ="a", directory_name[256]; /*define strings*/
	//check the quantity of the inputs
	if (argc!=3) {
		printf("Wrong Number of Arguments!!!\n"); /*present error message*/
		exit(1); /*exit from the program*/
	}
	//open restaurant_menu file
	strcpy(restaurant_menu,argv[1]);
	strcat(restaurant_menu,".txt");
	//check if the open succeed
	if ((fd = open(restaurant_menu, O_WRONLY | O_CREAT, 0664)) == -1)
		{
			perror("open restaurant_menu"); return(-1); /*error message*/
		}
	//write into the file
	if ((wbytes = write(fd, argv[1],strlen(argv[1]))) == -1)
		{
			perror("write"); return(-1); /*error message*/
		}
	//write into the file
	if ((wbytes = write(fd, " Menu\n\n",strlen(" Menu\n\n"))) == -1)
		{
			perror("write"); return(-1); /*error message*/
		}
	//write the menu
	for (index1=0;index1<atoi(argv[2]);index1++)
	{
		printf("Insert Type Dish %c:\n", (index1 + 97)); /*ask for type dish from user*/
		fgets(input, 25, stdin); /*receive the type dish from him*/
		//handle the end of the string(from '\n' to '\0')
		if (input[strlen(input) - 1] == '\n') {
			input[strlen(input) - 1] = '\0';
		}
		//write into the file
		strcpy(temp,temp1);
		strcat(temp, ". ");
		*temp1+=1;
		if ((wbytes = write(fd, temp, strlen(temp))) == -1)
			{
				perror("write"); return(-1); /*error message*/
			}
		//write into the file
		strcat(input, "\n");
		if ((wbytes = write(fd, input, strlen(input))) == -1)
			{
				perror("write"); return(-1); /*error message*/
			}
		//handle the dish itself
		do {
			printf("Insert dish name %d:\n", index2); /*ask for dish from user*/
			fgets(input, 25, stdin); /*receive the dish from him*/
			//handle the end of the string(from '\n' to '\0')
			if (input[strlen(input) - 1] == '\n') {
				input[strlen(input) - 1] = '\0';
				}
			//handle the dish and the price
			if (strcmp(input, "Stop")) {
				//write into the file
				if ((wbytes = write(fd, "  ", 2)) == -1)
					{
						perror("write"); return(-1); /*error message*/
					}
				 //use PresentLine function for handeling the dish and the price
				strcpy(input,PresentLine(input));
				//write into the file
				if ((wbytes = write(fd,input, strlen(input))) == -1)
					{
						perror("write"); return(-1); /*error message*/
					}
				//write into the file
				if ((wbytes = write(fd, "\n", 1)) == -1)
					{
						perror("write"); return(-1); /*error message*/
					}
				}
			index2++; /*procceed index2*/
			} while (strcmp(input, "Stop")); /*stop condition*/
			index2 = 1; /*initialize index2*/
	}
	//write into the file
	if ((wbytes = write(fd, "        Bon Appetit",strlen("        Bon Appetit"))) == -1)
		{
			perror("write"); return(-1); /*error message*/
		}
	//open dir
	strcpy(directory_name,argv[1]);
	strcat(directory_name,"_Order");
	//check open
	if ((check = mkdir(directory_name,0777))==(-1))
	{
		perror("not succeed open the dir."); return (-1);
	}
	//present messege for the user
	printf("Successfully created // %s.txt created , %s_Order dir created.\n", argv[1], argv[1]);
	close(fd); /*close file*/
	return 0; /*return 0*/
}
//define function that receive dish and present it like we need
char *PresentLine(char *input1) {
	int index3, wbytes1, counter; /*define integer variables*/
	char tempy[2], line[26] = {}; /*define strings*/
	char *Pline = line; /*define Pline*/
	//check the input
	for (index3=0;index3<strlen(input1);index3++) {
		tempy[0] = input1[index3];
		tempy[1] = '\0';
		//handle number
		if (tempy[0]>='0' && tempy[0]<='9') {
			counter = strlen(line);
			//handle the dots
			while (counter<17) {
				strcat(line,".");
				counter++; /*procceed counter*/
				}
			strcat(line," ");
			//handle the number inself
			while (index3<strlen(input1)) {
				//add letter
				tempy[0] = input1[index3];
				tempy[1] = '\0';
				strcat(line,tempy);
				index3++; /*procceed index3*/
				}
			strcat(line,"NIS");
			break; /*break*/
			}
		//handle the other chars
		else {
			strcat(line,tempy);
		}
	}
	return Pline; /*return Pline*/
}
