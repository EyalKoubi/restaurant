#include <stdio.h>
#include <stdlib.h> /*call memory allocation library*/
#include <string.h> /*call string library*/
#include <unistd.h> /*call fork library*/
#include <fcntl.h> /*call files library*/
#include <time.h> /*call time library*/
#define SIZE 256 /*define constant*/
//define function that copy the file 'from' into 'to' file at 'dir' directory
int copy(char* from, char* to, char* dir);
//main function
int main(int argc, char *argv[]) {
	//define integers variables
	int sum_price=0, fd_restaurant_order, fd_restaurant_menu, wbytes, rbytes, index=0, index1, un_link_cheker;
	//define strings, and pointers
	char user_choice[27], restaurant_order[SIZE], restaurant_menu[SIZE], *tok, *line, str[27], *number, number_two[4], dir[50], *file, str2[SIZE];
	//define time tools
	time_t t = time(NULL);
	struct tm tm = *localtime(&t);
	//check the quantity of the arguments
	if (argc!=3) {
		printf("Wrong Number of Arguments!!!\n"); /*present error message*/
		exit(1); /*exit from the program*/
	}
	//open restaurant_order folder
	strcpy(restaurant_order,argv[2]);
	strcat(restaurant_order,".txt");
	file = restaurant_order;
	//check if the open succeed
	if ((fd_restaurant_order = open(restaurant_order, O_WRONLY | O_CREAT, 0664)) == -1)
		{
			perror("open retaurant_order"); return(-1); /*error message*/
		}
	//write the name of the restaurant into the folder
	if ((wbytes = write(fd_restaurant_order, argv[1],strlen(argv[1]))) == -1)
		{
			perror("write"); return(-1); /*error message*/
		}
	//write "order" into the folder
	if ((wbytes = write(fd_restaurant_order, " order\n\n",strlen(" order\n\n"))) == -1)
		{
			perror("write"); return(-1); /*error message*/
		}
	//do strcat's where you need
	strcpy(dir,argv[1]);
	strcat(dir,"_Order");
	strcat(argv[1],".txt");
	//open restaurant_menu folder
	if ((fd_restaurant_menu = open(argv[1], O_RDONLY)) == -1)
		{
			printf("Restaurant Not Found!\n"); return(-1); /*error message*/
		}
	//ask order from the user
	printf("Insert your dish(Finish to finish):\n");
	do {
		//open the menu folder
		if ((fd_restaurant_menu = open(argv[1], O_RDONLY)) == -1)
			{
				perror("open restaurant_menu"); return(-1); /*error message*/
			}
		fgets(user_choice,27,stdin); /*receive dish from the user*/
		//handle the end of the string(from '\n' to '\0')
		if (user_choice[strlen(user_choice) - 1] == '\n') {
			user_choice[strlen(user_choice) - 1] = '\0';
		}
		//get the dish from the line
		while (user_choice[index]<'0' || user_choice[index]>'9') {
			str[index] = user_choice[index];
			index++;
		}
		str[(index-1)] = '\0'; /*close the string*/
		index1=0; /*initialize index1*/
		//get the quantity of the dish from the line
		while (user_choice[index]!='\0') {
			number_two[index1] = user_choice[index];
			index1++;
			index++;
		}
		//read the menu
		if ((rbytes = read(fd_restaurant_menu, restaurant_menu, SIZE)) == -1)
		{
			perror("read 1"); return(-1); /*error message*/
		}
		strcat(user_choice,"\n"); /*go down one line*/
		//write into the file
		if ((wbytes = write(fd_restaurant_order, user_choice,strlen(user_choice))) == -1)
		{
			perror("write"); return(-1); /*error message*/
		}
		//check each line
		tok = strtok(restaurant_menu,"\n");
		while (tok!=NULL) {
			line=tok;
			//check if the dish is on that line and get the price
			if (strstr(line,str)!=NULL && line[2]==str[0] && line[2+strlen(str)]==' ') {
				for (index=0;index<strlen(line);index++) {
					if (line[index]>='0' && line[index]<='9') {
						number=&line[index]; /*save the pointer of the number*/
						break; /*break*/
					}
				}
			}
		tok = strtok(NULL,"\n"); /*procceed the tok*/
		}
		close(fd_restaurant_menu); /*close the menu*/
		//check if the user finished
		if (strcmp(user_choice,"Finish\n")) {
			//add price to the sum
			sum_price+=atoi(number)*atoi(number_two);
		}
		index=0; /*initialize the index*/
	//check if the user finished
	} while (strcmp(user_choice,"Finish\n"));
	//write "Total Price:" to the order folder
	if ((wbytes = write(fd_restaurant_order, "Total Price: ",strlen("Total Price: "))) == -1)
		{
			perror("write"); return(-1); /*error message*/
		}
	sprintf(str2,"%d",sum_price); /*get sum price*/
	//write the sum price to the order folder
	if ((wbytes = write(fd_restaurant_order, str2,strlen(str2))) == -1)
		{
			perror("write"); return(-1); /*error message*/
		}
	//write "NIS" to the order folder
	if ((wbytes = write(fd_restaurant_order, "NIS",strlen("NIS"))) == -1)
		{
			perror("write"); return(-1); /*error message*/
		}
	//write "\n\n" to the order folder
	if ((wbytes = write(fd_restaurant_order, "\n\n",strlen("\n\n"))) == -1)
		{
			perror("write"); return(-1); /*error message*/
		}
	//get date
	sprintf(str2,"%d/%d/%d",tm.tm_mday,1 + tm.tm_mon,1900 + tm.tm_year);
	//write the date to the order folder
	if ((wbytes = write(fd_restaurant_order, str2,strlen(str2))) == -1)
		{
			perror("write"); return(-1); /*error message*/
		}
	//present the total price
	printf("Total Price: %d NIS (Confirm to approve/else cancel)\n",sum_price);
	fgets(user_choice,27,stdin); /*receive the user choice*/
	//check if the user confirm the order
	if (!(strcmp(user_choice,"Confirm\n"))) {
		/*present to the user the order exist*/
		printf("order created! // %s Created in %s Dir with Read Mode\n", restaurant_order, dir);
		copy(restaurant_order, file, dir); /*copy the folder into the order dir*/
	}
	//check if the delete succeed
	if ( (un_link_cheker=unlink(restaurant_order)) == (-1))
	{
		perror("unlink"); return (-1); /*error message*/
	}
	return 0; /*return 0*/
}
//define function that copy the file 'from' into 'to' file at 'dir' directory
int copy(char* from, char* to, char* dir) {
	int fd_from, fd_to, rbytes, wbytes; /*define integers variables*/
	char buff[256]; /*define string variable*/
	//open 'from' file to reading and present error if you need
	if ((fd_from = open(from, O_RDONLY)) == -1)
	{
		perror("open from"); return(-1);
	}
	//get in to the directory and present error if you need
	if (chdir(dir) == (-1))
	{
		perror("didn't succeed get in to the dir"); return (-1);
	}
	//open file 'to' for writing and present error if you need
	if ((fd_to = open(to, O_WRONLY | O_CREAT, 0664)) == -1)
	{
		perror("open to"); return(-1);
	}
	//get out from the directory and present error if you need
	if (chdir("..") == (-1))
	{
		perror("didn't succeed get out from the dir"); return (-1);
	}
	//read from 'from' folder and present error if you need
	if ((rbytes = read(fd_from, buff, 256)) == -1)
	{
		perror("read 1"); return(-1);
	}
	while (rbytes > 0) {
		//get in to the directory and present error if you need
		if (chdir(dir) == (-1))
		{
			//error message
			perror("didn't succeed get in to the dir"); return (-1);
		}
		//write to the buffer and present error if you need
		if ((wbytes = write(fd_to, buff, rbytes)) == -1)
		{
			perror("write"); return(-1); /*error message*/
		}
		//check if the action succeed
		if (wbytes != rbytes)
		{
			fprintf(stderr, "bad write\n"); return(-1); /*error message*/
		}
		//get out from the directory and present error if you need
		if (chdir("..") == (-1))
		{
			//error message
			perror("didn't succeed get out from the dir"); return (-1);
		}
		//read from 'from' folder and present error if you need
		if ((rbytes = read(fd_from, buff, 256)) == -1)
		{
			perror("read 2"); return(-1);
		}
	}
	chdir(dir); /*get into the dir*/
	//change the folder to reading
	if (chmod(to, 0444) == -1)
		{
			perror("chmod"); return(-1); /*error message*/
		}
	chdir(".."); /*get out from the dir*/
	close(fd_to); /*close to file*/
	return 0; /*return 0*/
}
