#include <stdio.h>
#include <stdlib.h> /*call memory allocation library*/
//main function
int main() {
	printf("Goodbye...\n"); /*present 'Goodbye' to user*/
	return 0; /*return 0*/
}
