#include <stdio.h>
#include <stdlib.h> /*call memory allocation library*/
#include <string.h> /*call string library*/
#include <unistd.h> /*call fork library*/
#include <fcntl.h> /*call files library*/
//main function
int main(int argc,char *argv[]) {
	int rbytes=1, fd_restaurant, index; /*define integer variables*/
	char buffer[5], *str; /*define strings*/
	//check the inractness of the input
	if (argc!=2) {
		printf("Wrong Number of Arguments!!!\n"); /*error message*/
		exit(1); /*exit from the program*/
	}	
	strcat(argv[1],".txt");
	//open menu restaurant file to reading and present error if you need
	if ((fd_restaurant = open(argv[1], O_RDONLY)) == -1)
	{
		perror("open from"); return(-1); /*error message and exit*/
	}
	while (rbytes>0) {
		//read from menu restaurant file and present error if you need
		if ((rbytes = read(fd_restaurant, buffer, 5)) == -1)
		{
			perror("read 2"); return(-1); /*error message and exit*/
		}
		str = (char*)malloc(strlen(buffer)+1); /*memory allocation*/
		//check if the allocation succeed
		if (str==NULL) {
			printf("Error Memory Allocation!!!\n"); /*present error message*/
			exit(1); /*exit from the program*/
		}
		strcpy(str,buffer);
		printf("%s",str); /*present string from the file*/
		//clean the buffer
		for (index=0;index<5;index++) {
			buffer[index] = '\0';
		}
	}
	free(str); /*free memory allocation*/
	close(fd_restaurant); /*close menu restaurant file*/
	return 0; /*return 0*/
}
