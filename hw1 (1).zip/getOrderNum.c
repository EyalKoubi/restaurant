#include <stdio.h>
#include <stdlib.h> /*call memory allocation library*/
#include <string.h> /*call string library*/
#include <unistd.h> /*call fork library*/
#include <fcntl.h> /*call files library*/
#include <dirent.h> /*call dirent library*/
#define SIZE 256 /*define 256 constant*/
int main(int argc, char *argv[]) {
	char dir_name[SIZE]; /*define 'dir_name' string*/
	int folder_counter = 0; /*define integer*/
	struct dirent * entrance; /*define dirent pointer*/
	DIR * dir_pointer; /*define DIR pointer*/
	//check the intactness of
	//the quantity of the argument
	if (argc!=2) {
		//present error message to the user
		printf("Wrong Number of Arguments!!!\n");
		exit(1); /*exit from the program*/
	}
	//create the directory name
	strcpy(dir_name,argv[1]);
	strcat(dir_name,"_Order");
	//open the directory
	if ( (dir_pointer = opendir(dir_name)) == NULL)
	{
		perror("dir"); return (-1); /*error message*/
	}
	//read the files
	while ((entrance = readdir(dir_pointer)) != NULL) {
		//check if the folder is txt folder
    	if (strstr(entrance->d_name,".txt")!=NULL) {
    	     folder_counter++; /*procceed 'folder_counter'*/
    	}
	}
	//present the quantity of the orders
	printf("%d Orders\n",folder_counter);
	closedir(dir_pointer); /*close the directory*/
	return 0; /*return 0*/
}
