#include <stdio.h>
#include <stdlib.h> /*call memory allocation library*/
#include <string.h> /*call string library*/
#include <unistd.h> /*call fork library*/
#include <fcntl.h> /*call files library*/
#define SIZE 1024 /*define 1024 constant*/
//main function
int main(int argc,char *argv[]) {
	int rbytes, fd_restaurant, flag, index=3; /*define integer variables*/
	flag = 0; /*initialize flag*/
	char str[SIZE], dish_name[SIZE], *line, *tok; /*define strings*/
	//check the intactness of the input
	if (argc<=2) {
		printf("Wrong Number of Arguments!!!\n"); /*error message*/
		exit(1); /*exit from the program*/
	}
	//get dish name
	strcpy(dish_name,argv[2]);
	for (index=3;index<argc;index++) {
		strcat(dish_name," ");
		strcat(dish_name,argv[index]);
	}
	//open menu restaurant file to reading and present error if you need
	strcat(argv[1],".txt");
	if ((fd_restaurant = open(argv[1], O_RDONLY)) == -1)
	{
		printf("Restaurant Not Found!\n"); return(-1); /*error message and exit*/
	}
	//read the file
	if ((rbytes = read(fd_restaurant, str, SIZE)) == -1)
		{
			perror("read 2"); return (-1); /*error message and exit*/
		}
	//check each line
	tok = strtok(str,"\n");
	while (tok!=NULL) {
		line=tok;
			//check if the dish is on that line and present the price
			if (strstr(line,dish_name)!=NULL && line[2]==dish_name[0] && line[2+strlen(dish_name)]==' ') {
				flag = 1;
				for (index=0;index<strlen(line);index++) {
					if (line[index]>='0' && line[index]<='9') {
						printf("%c",line[index]);
					}
				}
				printf(" NIS\n");
			}
		tok = strtok(NULL,"\n");
		}
	//check if the dish doesn't exist
	if (flag==0) {
		printf("dish Not Found!\n"); /*present the user you don't have this dish*/
	}
	close(fd_restaurant); /*close the file*/
	return 0; /*return 0*/
}
